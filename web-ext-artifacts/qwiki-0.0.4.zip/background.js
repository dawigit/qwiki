browser.tabs.executeScript(null, {file: "/content_scripts/quickwiki.js"});
/*browser.contextMenus.create({
  id: "quickwiki",
  title: "quickwiki"
});
browser.contextMenus.onClicked.addListener(function(info, tab) {
  if (info.menuItemId == "quickwiki") {
    console.log("qw_menu!");
    //browser.tabs.executeScript({file: "page-eater.js"});
  }
});*/
function bg_handleMessage(request, sender, sendResponse) {
  //console.log(`background.js recieved from ${sender}: ${request}`);
  //browser.runtime.onMessage.removeListener(bg_handleMessage);
  if(request.greeting){console.log("Message from the content script: " + request.greeting);}
  if(request.url){
    //console.log( `requested url: ${request.url}`);
    var xreq = new XMLHttpRequest();
    if(xreq){
        xreq.open('GET', request.url, true);
        xreq.onreadystatechange =  function() {
            if (xreq.readyState == 4) {
              sendResponse({
                data: xreq.responseText,
                method: request.method
              });
            }
        };
        xreq.send();
    }
  }
  return true;
}

browser.runtime.onMessage.addListener(bg_handleMessage);
